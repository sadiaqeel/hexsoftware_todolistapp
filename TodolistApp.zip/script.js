const input = document.getElementById('todo-input');
const addBtn = document.getElementById('add-btn');
const todoList = document.getElementById('todo-list');

let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
let currentFilter = 'all'; // <--- NEW: Track current filter state

// 1. Updated Render Function (Replaces the old one)
function renderTasks() {
    todoList.innerHTML = '';
    
    // Logic to filter which tasks actually get shown
    const filteredTasks = tasks.filter(task => {
        if (currentFilter === 'pending') return !task.completed;
        if (currentFilter === 'completed') return task.completed;
        return true; 
    });

    filteredTasks.forEach((task) => {
        // Find the original index so clicking delete/toggle 
        // still hits the right item in the main array
        const originalIndex = tasks.indexOf(task);
        
        const li = document.createElement('li');
        li.innerHTML = `
            <span class="task-text ${task.completed ? 'completed' : ''}" onclick="toggleTask(${originalIndex})">
                ${task.text}
            </span>
            <button class="delete-btn" onclick="deleteTask(${originalIndex})">Delete</button>
        `;
        todoList.appendChild(li);
    });
    saveTasks();
}

// 2. NEW: Function to handle filter button clicks
window.setFilter = (filter) => {
    currentFilter = filter;
    
    // Update visual "active" state of buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
        if(btn.textContent.toLowerCase() === filter) btn.classList.add('active');
    });
    
    renderTasks();
};

// 3. NEW: Function to wipe everything
window.clearAll = () => {
    if (confirm("Are you sure you want to delete all tasks?")) {
        tasks = [];
        renderTasks();
    }
};

// --- CORE LOGIC (Remains largely the same) ---

function addTask() {
    const text = input.value.trim();
    if (text !== '') {
        tasks.push({ text: text, completed: false });
        input.value = '';
        renderTasks();
    }
}

window.toggleTask = (index) => {
    tasks[index].completed = !tasks[index].completed;
    renderTasks();
};

window.deleteTask = (index) => {
    tasks.splice(index, 1);
    renderTasks();
};

function saveTasks() {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

addBtn.addEventListener('click', addTask);
input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTask();
});

renderTasks();